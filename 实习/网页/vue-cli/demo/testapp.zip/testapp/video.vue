<template>
  <div class="body">

   <div class="nav">
    <div class="title">
    <div class="title-img">
       <img src="../assets/picture/6.jpg"/>
     </div>
       <h1 class="title-text">
         生物群体行为
       </h1>
     </div>
     <div class="nav-a">
     <a href="#">首页</a>
     <a href="#">搜索</a>
     <a href="#">APIs</a>
     <a href="#">论文</a>
     <a href="#">关于</a>
     </div>
   </div>


    <div class="container">
      <h2>生物行为视频描述</h2>
      <div class="video">
      <video v-bind:src="getUrl(videoArr[vindex])" controls="controls">your browser does not support the vedio tag</video>
      <a href="javascipt:void(0)" v-show="vindex!=0" @click="vprev" class="vprev">&lt;</a>
      <a href="javascipt:void(0)" v-show="vindex<videoArr.length-1" @click="vnext" class="vnext">&gt;</a>
      </div>
      <div id="detail" class="basic-info container">
      <dl v-for="(n,m) in videoInfo[vindex]" :key="n" class="basicInfo-block basicInfo-left">
        <dt v-bind:title="m" class="basicInfo-item name">{{m}}</dt>
        <dd v-bind:title="n" class="basicInfo-item value">{{n}}</dd>
      </dl>
      </div>
    </div>

  </div>
</template>

<script>
export default {
  name: "detail",
  components: {},
  data() {
    return {
      videoArr:[],
      videoInfo:[],
      vindex:0
    };
  },

  mounted: function () {
    this.showItems()
  },

  methods: {
    vprev: function(){
      this.vindex--
    },
    vnext: function(){
      this.vindex++
    },
    getUrl:function(url){
      const a = require('url')
      return a;
    },
    showItems() {
      this.$http.get('http://127.0.0.1:8000/api/BiobehaviorInformation?name=' + '大象').then((response) => {
        var res = JSON.parse(response.bodyText)
        console.log(res)
        if (res.error_num === 0) {
          this.videoInfo = res['text']
          this.videoArr = res['video']
        } else {
          this.$message.error('error')
          console.log(res['msg'])
        }
      })
    }

  },
};
</script>

<style>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}
.div {
  display: block;
}

.body {
  font-family: "Helvetica Neue", Arial, Helvetica, sans-serif;
  font-size: 14px;
  color: #333;
  background-color: #fff;
  line-height: 1.42857143;
  text-size-adjust: 100%;
}
.dl {
  display: block;
  margin-block-start: 1em;
  margin-block-end: 1em;
  margin-inline-start: 0px;
  margin-inline-end: 0px;
}
.dt {
  display: block;
}
.dd {
  display: block;
  margin-inline-start: 40px;
}
.basic-info {
  margin: 20px 0 35px;
  clear: both;
  overflow: hidden;
  background: url('./assets/picture/basicInfo-bg.png');
}

.basic-info .basicInfo-block {
  width: 500px;
  float: left;
}

.basic-info .basicInfo-block .basicInfo-item {
  line-height: 26px;
  display: block;
  padding: 0;
  margin: 0;
  float: left;
}

.basic-info .basicInfo-block .basicInfo-item.name {
  width: 150px;
  padding: 0 5px 0 12px;
  font-weight: 700;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  word-wrap: normal;
  color: #999;
}

.basic-info .basicInfo-block .basicInfo-item.value {
  zoom: 1;
  color: #333;
  width: 350px;
  float: left;
  position: relative;
  word-break: break-all;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  word-wrap: normal;
}

.container {
  margin-left: 10px;
  margin-right: 10px;
  margin-top: 10px;
  padding-left: 15px;
  padding-right: 15px;
  width: 95%;
  float: left;
}

.container h2 {
  background: rgb(17,114,224);
  color:rgb(255,250,250);
  }

.video {
  position: relative;
  width:520px;
  height:280px;
  margin: 5px auto;
}
.video video{
  width:100%;
  height:280px;
}
.vprev,
.vnext {
  position: absolute;
  top: 50%;
  margin-top: -15px;
  width: 20px;
  height: 30px;
  background-color: rgba(0, 0, 0, 0.3);
  text-align: center;
  line-height: 30px;
  color: #fff;
  text-decoration: none;
}
.vprev {
  left: 0;
  border-top-right-radius: 15px;
  border-bottom-right-radius: 15px;
}
.vnext {
  right: 0;
  border-top-left-radius: 15px;
  border-bottom-left-radius: 15px;
}
.pictures {
  position: relative;
  width: 520px;
  height: 280px;
  margin: 5px auto;
}
.pictures img {
  width: 520px;
  height: 280px;
}


.nav {
  height: 80px;
  border-top: 1px solid rgb(17,114,224);
  border-bottom: 2px solid #edeff0;
  background-color:#edeff0;
  line-height: 80px;
}
.nav div {
  float:left;
}
.nav a{
  display: inline-block;
  height: 30px;
  padding: 0 30px;
  font-size:20px;
  font-family: "宋体";
  font-weight: bold;
  color:rgb(255,250,250);
  text-decoration: none;
}
.nav a:hover {
  background-color: rgb(10,100,170);
  color:#ff8500
}
.title {
  background-image: url("./assets/picture/5.jpg");
  width:100%;
  height:60px;
}
.title-text {
  font-weight: bold;
  font-size:50px;
  font-family: kaiti;
  color:rgb(0,0,0);
}
.title-img {
   height:60px;
   width:70px;
   background-image: url("./assets/picture/6.jpg");
}
.title-img img{
  display:inline-block;
  height:60px;
  width:70px
}
.nav-a {
   width:100%;
   height:30px;
   line-height:30px;
   background-color: rgb(17, 114, 224)
}
</style>

