<template>
  <div class="body">
    <div class="nav">
      <div class="title">
        <div class="title-img">
          <img src="./assets/pictures/6.jpg" />
        </div>
        <h1 class="title-text">生物群体行为</h1>
      </div>
      <div class="nav-a">
        <a href="#">首页</a>
        <a href="#">搜索</a>
        <a href="#">APIs</a>
        <a href="#">论文</a>
        <a href="#">关于</a>
      </div>
    </div>

    <!-- 表单 -->
    <span>总数量：{{total}}个</span>
    <el-table
      :data="tableData.slice((currentPage-1)*pagesize,currentPage*pagesize)"
      class="table"
    >
      <el-table-column prop="date" label="日期" width="180"></el-table-column>
      <el-table-column prop="name" label="视频名" width="180"></el-table-column>
        <el-table-column prop="animal" label="涉及动物" width="180"></el-table-column>
      <el-table-column label="观看地址">
        <template slot-scope="scope">
          <el-button type="primary" icon="el-icon-view"></el-button>
        </template>
      </el-table-column>
    </el-table>

    <!-- 分页 -->
    <el-pagination
      class="pageination"
      layout="prev, pager, next"
      @current-change="current_change"
      :total=total
      background
    ></el-pagination>
  </div>
</template>

<script>
export default {
  name: "detail",
  components: {},
  data() {
    return {
      total: 100, // 默认数据总数
      pagesize: 10, // 每页的数据条数
      currentPage: 1, //默认开始页面
      tableData: [
        {
          date: "2016-05-02",
          name: "老虎游泳1",
          animal: "老虎",
          address: "",
        },
        {
          date: "2016-05-04",
          name: "大象爬树1",
          animal: "大象",
          address: "",
        },
        {
          date: "2016-05-01",
          name: "狮子吃草1",
          animal: "狮子",
          address: "",
        },
        {
          date: "2016-05-03",
          name: "乌龟上天1",
          animal: "乌龟",
          address: "",
        },
        {
          date: "2016-05-04",
          name: "兔子下海1",
          animal: "兔子",
          address: "",
        },
       {
          date: "2016-05-02",
          name: "老虎游泳2",
          animal: "老虎",
          address: "",
        },
        {
          date: "2016-05-04",
          name: "大象爬树2",
          animal: "大象",
          address: "",
        },
        {
          date: "2016-05-01",
          name: "狮子吃草2",
          animal: "狮子",
          address: "",
        },
        {
          date: "2016-05-03",
          name: "乌龟上天2",
          animal: "乌龟",
          address: "",
        },
        {
          date: "2016-05-04",
          name: "兔子下海2",
          animal: "兔子",
          address: "",
        },
         {
          date: "2016-05-02",
          name: "老虎游泳3",
          animal: "老虎",
          address: "",
        },
        {
          date: "2016-05-04",
          name: "大象爬树3",
          animal: "大象",
          address: "",
        },
        {
          date: "2016-05-01",
          name: "狮子吃草3",
          animal: "狮子",
          address: "",
        },
        {
          date: "2016-05-03",
          name: "乌龟上天3",
          animal: "乌龟",
          address: "",
        },
        {
          date: "2016-05-04",
          name: "兔子下海3",
          animal: "兔子",
          address: "",
        },
        {
          date: "2016-05-02",
          name: "老虎游泳4",
          animal: "老虎",
          address: "",
        },
        {
          date: "2016-05-04",
          name: "大象爬树4",
          animal: "大象",
          address: "",
        },
        {
          date: "2016-05-01",
          name: "狮子吃草4",
          animal: "狮子",
          address: "",
        },
        {
          date: "2016-05-03",
          name: "乌龟上天4",
          animal: "乌龟",
          address: "",
        },
        {
          date: "2016-05-04",
          name: "兔子下海4",
          animal: "兔子",
          address: "",
        },
        {
          date: "2016-05-02",
          name: "老虎游泳5",
          animal: "老虎",
          address: "",
        },
        {
          date: "2016-05-04",
          name: "大象爬树5",
          animal: "大象",
          address: "",
        },
        {
          date: "2016-05-01",
          name: "狮子吃草5",
          animal: "狮子",
          address: "",
        },
        {
          date: "2016-05-03",
          name: "乌龟上天5",
          animal: "乌龟",
          address: "",
        },
        {
          date: "2016-05-04",
          name: "兔子下海5",
          animal: "兔子",
          address: "",
        },
      {
          date: "2016-05-02",
          name: "老虎游泳6",
          animal: "老虎",
          address: "",
        },
        {
          date: "2016-05-04",
          name: "大象爬树6",
          animal: "大象",
          address: "",
        },
        {
          date: "2016-05-01",
          name: "狮子吃草6",
          animal: "狮子",
          address: "",
        },
        {
          date: "2016-05-03",
          name: "乌龟上天6",
          animal: "乌龟",
          address: "",
        },
        {
          date: "2016-05-04",
          name: "兔子下海6",
          animal: "兔子",
          address: "",
        }
      ],
    };
  },

   created:function(){
         this.total=this.tableData.length;
      },

  methods: {
    current_change: function (currentPage) {
      this.currentPage = currentPage;
    },
  },
};
</script>

<style>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}
.div {
  display: block;
}

.body {
  font-family: "Helvetica Neue", Arial, Helvetica, sans-serif;
  font-size: 14px;
  color: #333;
  background-color: #fff;
  line-height: 1.42857143;
  text-size-adjust: 100%;
}
.dl {
  display: block;
  margin-block-start: 1em;
  margin-block-end: 1em;
  margin-inline-start: 0px;
  margin-inline-end: 0px;
}
.dt {
  display: block;
}
.dd {
  display: block;
  margin-inline-start: 40px;
}
.basic-info {
  margin: 20px 0 35px;
  clear: both;
  overflow: hidden;
  background: url("./assets/pictures/basicInfo-bg.png");
}

.basic-info .basicInfo-block {
  width: 500px;
  float: left;
}

.basic-info .basicInfo-block .basicInfo-item {
  line-height: 26px;
  display: block;
  padding: 0;
  margin: 0;
  float: left;
}

.basic-info .basicInfo-block .basicInfo-item.name {
  width: 150px;
  padding: 0 5px 0 12px;
  font-weight: 700;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  word-wrap: normal;
  color: #999;
}

.basic-info .basicInfo-block .basicInfo-item.value {
  zoom: 1;
  color: #333;
  width: 350px;
  float: left;
  position: relative;
  word-break: break-all;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  word-wrap: normal;
}

.container {
  margin-left: 10px;
  margin-right: 10px;
  margin-top: 10px;
  padding-left: 15px;
  padding-right: 15px;
  width: 95%;
  float: left;
}

.container h2 {
  background: rgb(17, 114, 224);
  color: rgb(255, 250, 250);
}

.video {
  position: relative;
  width: 520px;
  height: 280px;
  margin: 5px auto;
}
.video video {
  width: 100%;
  height: 280px;
}
.vprev,
.vnext {
  position: absolute;
  top: 50%;
  margin-top: -15px;
  width: 20px;
  height: 30px;
  background-color: rgba(0, 0, 0, 0.3);
  text-align: center;
  line-height: 30px;
  color: #fff;
  text-decoration: none;
}
.vprev {
  left: 0;
  border-top-right-radius: 15px;
  border-bottom-right-radius: 15px;
}
.vnext {
  right: 0;
  border-top-left-radius: 15px;
  border-bottom-left-radius: 15px;
}
.pictures {
  position: relative;
  width: 520px;
  height: 280px;
  margin: 5px auto;
}
.pictures img {
  width: 520px;
  height: 280px;
}

.nav {
  height: 80px;
  border-top: 1px solid rgb(17, 114, 224);
  border-bottom: 2px solid #edeff0;
  background-color: #edeff0;
  line-height: 80px;
}
.nav div {
  float: left;
}
.nav a {
  display: inline-block;
  height: 30px;
  padding: 0 30px;
  font-size: 20px;
  font-family: "宋体";
  font-weight: bold;
  color: rgb(255, 250, 250);
  text-decoration: none;
}
.nav a:hover {
  background-color: rgb(10, 100, 170);
  color: #ff8500;
}
.title {
  background-image: url("./assets/pictures/5.jpg");
  width: 100%;
  height: 60px;
}
.title-text {
  font-weight: bold;
  font-size: 50px;
  font-family: kaiti;
  color: rgb(0, 0, 0);
}
.title-img {
  height: 60px;
  width: 70px;
  background-image: url("./assets/pictures/6.jpg");
}
.title-img img {
  display: inline-block;
  height: 60px;
  width: 70px;
}
.nav-a {
  width: 100%;
  height: 30px;
  line-height: 30px;
  background-color: rgb(17, 114, 224);
}
.table {
  width:100%;
  text-align: center;
}
.pageination {
  text-align: center;
  margin-top: 30px;
}
</style>

 