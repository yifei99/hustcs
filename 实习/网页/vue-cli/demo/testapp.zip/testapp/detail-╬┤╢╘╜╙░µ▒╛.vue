<template>
  <div class="body">
  
   <div class="nav">
    <div class="title">
    <div class="title-img">
       <img src="./assets/pictures/6.jpg"/>
     </div>
       <h1 class="title-text">
         生物群体行为
       </h1>
     </div>
     <div class="nav-a">
     <a href="#">首页</a>
     <a href="#">搜索</a>
     <a href="#">APIs</a>
     <a href="#">论文</a>
     <a href="#">关于</a>
     </div>
   </div>
    

    <div class="container">
      <h2>生物视频描述</h2>
      <div class="video">
      <video v-bind:src="getUrl(videoArr[vindex].src)" controls="controls">your browser does not support the vedio tag</video>
      <a href="javascipt:void(0)" v-show="vindex!=0" @click="vprev" class="vprev">&lt;</a>
      <a href="javascipt:void(0)" v-show="vindex<videoArr.length-1" @click="vnext" class="vnext">&gt;</a>
      </div>
      <div id="detail" class="basic-info container">
      <dl v-for="(n,m) in videoArr[vindex].message" :key="n" class="basicInfo-block basicInfo-left">
        <dt v-bind:title="n.title" class="basicInfo-item name">{{n.title}}</dt>
        <dd v-bind:title="n.content" class="basicInfo-item value">{{n.content}}</dd>
      </dl>
      </div>
    </div>



    <div class="container">
      <h2>生物行为图片描述</h2>
      <div class="pictures" id="detail">
        <img v-bind:src="getUrl(imgArr[index])" >
        <a href="javascipt:void(0)" v-show="index!=0" @click="prev" class="prev">&lt;</a>
        <a href="javascipt:void(0)" v-show="index<imgArr.length-1" @click="next" class="next">&gt;</a>
      </div>
    </div>



    <div id="detail" class="basic-info container">
      <h2>生物行为文字描述</h2>
      <dl v-for="(it,m) in item" class="basicInfo-block basicInfo-left">
        <dt v-bind:title="item[m].title" class="basicInfo-item name">{{item[m].title}}</dt>
        <dd v-bind:title="item[m].content" class="basicInfo-item value">{{item[m].content}}</dd>
      </dl>
    </div>

    
  </div>
</template>

<script>
export default {
  name: "detail",
  components: {},
  data() {
    return {
      item: [
        {
          title: "中文学名",
          content: "大象"
        },
        {
          title: "拉丁学名",
          content: "Elephantidae"
        },
        {
          title: "别称",
          content: "大象"
        },
        {
          title: "界",
          content: "动物界"
        },
        {
          title: "门",
          content: "脊索动物门"
        },
        {
          title: "亚门",
          content: "哺乳纲"
        },
        {
          title: "纲",
          content: "真兽亚纲"
        },
        {
          title: "亚纲",
          content: "长鼻目"
        },
        {
          title: "目",
          content: "象科"
        },
        {
          title: "属",
          content: "亚洲象属、非洲象属"
        },
        {
          title: "种",
          content: "普通非洲象，非洲森林象，亚洲象普通非洲象，非洲森林象，亚洲象普通非洲象，非洲森林象，亚洲象普通非洲象，非洲森林象，亚洲象普通非洲象，非洲森林象，亚洲象普通非洲象，非洲森林象，亚洲象普通非洲象，非洲森林象，亚洲象普通非洲象，非洲森林象，亚洲象普通非洲象，非洲森林象，亚洲象普通非洲象，非洲森林象，亚洲象普通非洲象，非洲森林象，亚洲象普通非洲象，非洲森林象，亚洲象普通非洲象，非洲森林象，亚洲象普通非洲象，非洲森林象，亚洲象普通非洲象，非洲森林象，亚洲象普通非洲象，非洲森林象，亚洲象普通非洲象，非洲森林象，亚洲象普通非洲象，非洲森林象，亚洲象普通非洲象，非洲森林象，亚洲象普通非洲象，非洲森林象，亚洲象普通非洲象，非洲森林象，亚洲象普通非洲象，非洲森林象，亚洲象"
        },
      ],
      imgArr: [
        "./assets/pictures/ele1.jpg",
        "./assets/pictures/ele2.jpg",
        "./assets/pictures/ele3.jpg",
        "./assets/pictures/ele4.jpg",
        "./assets/pictures/ele5.jpg",
      ],
      videoArr:[
        {
          src:"./assets/video/ele.mp4",
          message:[
            {
              title:"视频名",
              content:"维多利亚瀑布"
            },
            {
              title:"主角名",
              content:"非洲象 Loxodonta africana"
            },
            {
              title:"主角动物规模",
              content:"4-6只"
            },
            {
              title:"集体行为",
              content:"正常移动"
            },
            {
              title:"行为模式",
              content:"调控"
            },
            {
              title:"行为刺激",
              content:"鬣狗闯入"
            }
          ]
        },
        {
          src:"./assets/video/ele2.mp4",
          message:[
            {
              title:"视频名",
              content:"大象的秘密生活第一集"
            },
            {
              title:"主角名",
              content:"非洲象 Loxodonta africana"
            },
            {
              title:"主角动物规模",
              content:"2-3只"
            },
            {
              title:"集体行为",
              content:"飞行"
            },
            {
              title:"行为模式",
              content:"应激"
            }
          ]
        }
      ],
      index: 0,
      vindex:0
    };
  },
  methods: {
    prev: function () {
      this.index--;
    },
    next: function () {
      this.index++;
    },
    vprev: function(){
      this.vindex--;
    },
    vnext: function(){
      this.vindex++;
    },
    getUrl:function(url){
      const a = require(''+url+'');
      return a;
    }
  },
};
</script>

<style>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}
.div {
  display: block;
}

.body {
  font-family: "Helvetica Neue", Arial, Helvetica, sans-serif;
  font-size: 14px;
  color: #333;
  background-color: #fff;
  line-height: 1.42857143;
  text-size-adjust: 100%;
}
.dl {
  display: block;
  margin-block-start: 1em;
  margin-block-end: 1em;
  margin-inline-start: 0px;
  margin-inline-end: 0px;
}
.dt {
  display: block;
}
.dd {
  display: block;
  margin-inline-start: 40px;
}
.basic-info {
  margin: 20px 0 35px;
  clear: both;
  overflow: hidden;
  background: url('./assets/pictures/basicInfo-bg.png');
}

.basic-info .basicInfo-block {
  width: 500px;
  float: left;
}

.basic-info .basicInfo-block .basicInfo-item {
  line-height: 26px;
  display: block;
  padding: 0;
  margin: 0;
  float: left;
}

.basic-info .basicInfo-block .basicInfo-item.name {
  width: 150px;
  padding: 0 5px 0 12px;
  font-weight: 700;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  word-wrap: normal;
  color: #999;
}

.basic-info .basicInfo-block .basicInfo-item.value {
  zoom: 1;
  color: #333;
  width: 350px;
  float: left;
  position: relative;
  word-break: break-all;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  word-wrap: normal;
}

.container {
  margin-left: 10px;
  margin-right: 10px;
  margin-top: 10px;
  padding-left: 15px;
  padding-right: 15px;
  width: 95%;
  float: left;
}

.container h2 {
  background: rgb(17,114,224);
  color:rgb(255,250,250);
  }

.video {
  position: relative;
  width:520px;
  height:280px;
  margin: 5px auto;
}
.video video{
  width:100%;
  height:280px;
}
.vprev,
.vnext {
  position: absolute;
  top: 50%;
  margin-top: -15px;
  width: 20px;
  height: 30px;
  background-color: rgba(0, 0, 0, 0.3);
  text-align: center;
  line-height: 30px;
  color: #fff;
  text-decoration: none;
}
.vprev {
  left: 0;
  border-top-right-radius: 15px;
  border-bottom-right-radius: 15px;
}
.vnext {
  right: 0;
  border-top-left-radius: 15px;
  border-bottom-left-radius: 15px;
}
.pictures {
  position: relative;
  width: 520px;
  height: 280px;
  margin: 5px auto;
}
.pictures img {
  width: 520px;
  height: 280px;
}
.prev,
.next {
  position: absolute;
  top: 50%;
  margin-top: -15px;
  width: 20px;
  height: 30px;
  background-color: rgba(0, 0, 0, 0.3);
  text-align: center;
  line-height: 30px;
  color: #fff;
  text-decoration: none;
}
.prev {
  left: 0;
  border-top-right-radius: 15px;
  border-bottom-right-radius: 15px;
}
.next {
  right: 0;
  border-top-left-radius: 15px;
  border-bottom-left-radius: 15px;
}

.nav {
  height: 80px;
  border-top: 1px solid rgb(17,114,224);
  border-bottom: 2px solid #edeff0;
  background-color:#edeff0;
  line-height: 80px;
}
.nav div {
  float:left;
}
.nav a{
  display: inline-block;
  height: 30px;
  padding: 0 30px;
  font-size:20px;
  font-family: "宋体";
  font-weight: bold;
  color:rgb(255,250,250);
  text-decoration: none;
}
.nav a:hover {
  background-color: rgb(10,100,170);
  color:#ff8500
}
.title {
  background-image: url("./assets/pictures/5.jpg");
  width:100%;
  height:60px;
} 
.title-text {
  font-weight: bold;
  font-size:50px;
  font-family: kaiti;
  color:rgb(0,0,0);
}
.title-img {
   height:60px;
   width:70px;
   background-image: url("./assets/pictures/6.jpg");
}
.title-img img{
  display:inline-block;
  height:60px;
  width:70px
}
.nav-a {
   width:100%;
   height:30px;
   line-height:30px;
   background-color: rgb(17, 114, 224)
}
</style>

 